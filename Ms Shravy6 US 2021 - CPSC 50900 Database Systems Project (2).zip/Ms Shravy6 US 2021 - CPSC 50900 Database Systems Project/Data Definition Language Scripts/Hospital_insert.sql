
INSERT INTO Patient VALUES(1,'Yasmin Matthews','48 Farburn Terrace',0708194285,'1989-02-12','Female','yasminmatthews@gmail.com','Childhood illnesses','Out Patient');
INSERT INTO Patient VALUES(2,'Michael Lever','53 Simone Weil Avenue',0777150148,'1983-01-17','Male','michaelalever@gmail.com','Allergies','In Patient');
INSERT INTO Patient VALUES(3,'Natasha Johnson','61 Hull Road',0792460481,'1997-07-15','Female','natashajohnson@gmail.com','Nill','Out Patient');
INSERT INTO Patient VALUES(4,'Eva King','30 Golden Knowes Road',0782148599,'1980-03-26','Female','evaking@gmail.com','Nill','In Patient');
INSERT INTO Patient VALUES(5,'Humberto Sanchez','87 Baldock Street',0773091147,'1992-04-03','Male','humbertojsanchez@gmail.com','Prior injuries','In Patient');
INSERT INTO Patient VALUES(6,'Timothy Thomas','15 Station Rd',0705077430,'1993-10-24','Male','timothyjthomas@gmail.com','Nill','Out Patient');



INSERT INTO Doctor VALUES(10,'Kayleigh Reynolds','93 Broad Street',0742312074,'1965-03-19','Female','kayleighreynolds@gmail.com','Pediatricians',2);
INSERT INTO Doctor VALUES(20,'Douglas Nazario','25 High St',0781003332,'1966-08-21','Male','douglasrnazario@gmail.com','Neurologists',1);
INSERT INTO Doctor VALUES(30,'Arthur Adair','46 Victoria Road',0783005740,'1961-06-20','Male','arthurhadair@gmail.com','Dermatologists',0);
INSERT INTO Doctor VALUES(40,'Ivan A. Shank','83 Merthyr Road',0780938505,'1978-04-14','Male','ivanashank@gmail.com','Anesthesiologists',4);
INSERT INTO Doctor VALUES(50,'Mollie Pratt','7 Bootham Crescent',0790810312,'1972-05-10','Female','molliepratt@gmail.com','Psychiatrists',3);
INSERT INTO Doctor VALUES(60,'Megan Thomas','92 Graham Road',0788955514,'1983-08-07','Female','meganthomas@gmail.com','Surgeon',2);




INSERT INTO Treatment VALUES(100,'Self care and bronchodilators',52,'Asthma');
INSERT INTO Treatment VALUES(101,'Treatment consists of immunosuppressants',220,'Rheumatoid Arthritis');
INSERT INTO Treatment VALUES(102,'Anti-inflammatories',5,'Kawasaki Syndrome');
INSERT INTO Treatment VALUES(103,'Use a triple layer medical mask',15,'COVID-19');
INSERT INTO Treatment VALUES(104,'Surgery,chemotherapy.',21,'Stomach cancer');
INSERT INTO Treatment VALUES(105,'Treatment consists of antacid',56,'Ulcers');


INSERT INTO Appointment VALUES(11,'2020-12-25',100,30,1);
INSERT INTO Appointment VALUES(12,'2019-03-04',100,10,4);
INSERT INTO Appointment VALUES(13,'2018-09-17',102,20,5);
INSERT INTO Appointment VALUES(14,'2021-07-19',104,30,6);
INSERT INTO Appointment VALUES(15,'2021-02-14',105,40,2);
INSERT INTO Appointment VALUES(16,'2020-11-30',103,50,3);



INSERT INTO Prescription VALUES(1,'Ultrasonic Mesh Nebulize',10,99.00,13);
INSERT INTO Prescription VALUES(2,'Acuprin Tablet',20,25.60,11);
INSERT INTO Prescription VALUES(3,'HealthXP Caffeine 200mg',15,39.90,14);
INSERT INTO Prescription VALUES(4,'Pandoz-HP Kit Tablet',6,53.20,15);
INSERT INTO Prescription VALUES(5,'Remdesevir injection, 100mg',5,48.01,16);



INSERT INTO Bill VALUES(123,110.00,'2018-09-17',1);
INSERT INTO Bill VALUES(124,30.00,'2020-12-25',2);
INSERT INTO Bill VALUES(125,45.25,'2021-07-19',3);
INSERT INTO Bill VALUES(126,61.20,'2021-02-14',4);
INSERT INTO Bill VALUES(127,51.15,'2020-11-30',5);

