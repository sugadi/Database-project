

-- two insert statements

INSERT INTO Patient VALUES(7,'Hayden Mann','49 Front Street',0772949014,'1943-09-02','Male','haydenmann@gmail.com','Nill','In Patient');
INSERT INTO Appointment VALUES(17,'2019-07-13',102,20,7);

-- two update statements
UPDATE Appointment
SET Doctor_ID = 20
WHERE Appointment_ID = 14;

UPDATE Bill
SET Bill_Amount = 50.00
WHERE Bill_ID = 127;


-- delete statement
DELETE FROM Bill WHERE Bill_ID = 127;


-- simple select statement
SELECT * FROM Patient;


-- 2 join statements
SELECT P.Patient_ID, P.Full_Name, A.Appointment_Date_Time
FROM Patient AS P INNER JOIN Appointment AS A
ON P.Patient_ID = A.Patient_ID;


SELECT T.Treatment_Desc, P.Medicine_Name
FROM Treatment AS T JOIN Appointment AS A JOIN Prescription AS P
ON T.Treatment_ID = A.Treatment_ID
WHERE A.Appointment_ID = P.Appointment_ID;


-- two that use summary statements
SELECT Appointment_ID, Medicine_Name, SUM(Total_Price) AS 'TotalPrice'
FROM Prescription
GROUP BY Appointment_ID, Medicine_Name;


SELECT Appointment_ID, COUNT(Doctor_ID)
FROM Appointment
GROUP BY Appointment_ID;


-- multi-table query
SELECT P.Full_Name AS 'Patient Full Name', D.Full_Name AS 'Doctor Full Name', A.Appointment_Date_Time,
PR.Prescription_ID
FROM Patient AS P, Doctor AS D, Appointment AS A, Prescription AS PR
WHERE P.Patient_ID = A.Patient_ID
AND D.Doctor_ID = A.Doctor_ID
AND A.Appointment_ID = PR.Appointment_ID;


-- query of your choice
SELECT *
FROM Treatment
WHERE Treatment_ID NOT IN (SELECT Treatment_ID FROM Appointment);















