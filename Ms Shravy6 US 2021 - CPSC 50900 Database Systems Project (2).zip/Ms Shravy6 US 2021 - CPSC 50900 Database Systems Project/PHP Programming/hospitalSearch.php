

<?php

if(isset($_POST['search']))
{
    $searchValue = $_POST['searchValue'];
    // select table all columns
    $query = "SELECT * FROM `doctor` WHERE Full_Name LIKE '".$searchValue."%'";
    $searchResult = tableValues($query);
    
}
 else {
    $query = "SELECT * FROM `doctor`";
    $searchResult = tableValues($query);
}

// function to conne and execute the query
function tableValues($query)
{
    $conne = mysqli_connect("localhost", "root", "", "hospitaldb");
    $filterResult = mysqli_query($conne, $query);
    return $filterResult;
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Doctor SEARCH</title>
        <style>
		h1{
		font-family:Georgia;
		}
            table,tr,th,td
            {
				font-family:Georgia;
                border: 1px solid black;
            }
        </style>
    </head>
    <body>
	
        <center>
		<h1>Doctor Details</h1>
        <form action="hospitalSearch.php" method="post">
            <input type="text" name="searchValue" placeholder="Value To Search"><br><br>
            <input type="submit" name="search" value="Search"><br><br>
            
            <table>
                <tr>
                    <th> Doctor Name </th>
                    <th> Address </th>
                    <th> Contact No </th>
                    <th> Specialty </th>
                </tr>

                <?php while($row = mysqli_fetch_array($searchResult)):?>
                <tr>
                    <td><?php echo $row['Full_Name']; ?></td>
                    <td><?php echo $row['Address'];?></td>
                    <td><?php echo $row['Contact_Number'];?></td>
                    <td><?php echo $row['Specialty'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
			
        </form>
		</center>
        
    </body>
</html>