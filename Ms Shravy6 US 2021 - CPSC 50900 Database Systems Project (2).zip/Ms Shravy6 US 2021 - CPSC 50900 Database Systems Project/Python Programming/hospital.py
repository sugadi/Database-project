
#import mysql connector file 
import mysql.connector
# details of mysql connection
mydb = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'root',
    port = '3307',
    database = 'hospitaldb'
)
mycursor = mydb.cursor()
# select patient table from database
mycursor.execute("select *from patient")
hospital_db = mycursor.fetchall()
print("******* Patient Details *******")
# write the details in text file 
with open('patient.txt','w') as f:
    for i in hospital_db:
        f.write(str(i))
        f.write('\n')
        # print result 
        print(i)

mycursor = mydb.cursor()
# select appointment table from database
mycursor.execute("select *from appointment")
hospital_db = mycursor.fetchall()
print("\n\n******* Appointment Details *******")
# write the details in text file 
with open('appointment.txt','w') as f:
    for i in hospital_db:
        f.write(str(i))
        f.write('\n')
        # print result
        print(i)

mycursor = mydb.cursor()
# select doctor table from database
mycursor.execute("select *from doctor")
hospital_db = mycursor.fetchall()
print("\n\n******* Doctor Details *******")
# write the details in text file 
with open('doctor.txt','w') as f:
    for i in hospital_db:
        f.write(str(i))
        f.write('\n')
        # print result
        print(i)

mycursor = mydb.cursor()
# select bill table from database
mycursor.execute("select * from bill")
hospital_db = mycursor.fetchall()
print("\n\n******* Bill Details *******")
# write the details in text file
with open('bill.txt','w') as f:
    for i in hospital_db:
        f.write(str(i))
        f.write('\n')
        # print result
        print(i)


mycursor = mydb.cursor()
# select prescription table from database
mycursor.execute("select *from prescription")
hospital_db = mycursor.fetchall()
print("\n\n******* Prescription Details *******")
# write the details in text file
with open('prescription.txt','w') as f:
    for i in hospital_db:
        f.write(str(i))
        f.write('\n')
        # print result
        print(i)

mycursor = mydb.cursor()
# select prescription table from database
mycursor.execute("select *from treatment")
hospital_db = mycursor.fetchall()
print("\n\n******* Treatment Details *******")
# write the details in text file
with open('treatment.txt','w') as f:
    for i in hospital_db:
        f.write(str(i))
        f.write('\n')
        # print result
        print(i)
